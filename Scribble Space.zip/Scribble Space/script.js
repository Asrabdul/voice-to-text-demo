import { Document, Packer, Paragraph, TextRun } from "docx";
import { saveAs } from "file-saver";

document.addEventListener('DOMContentLoaded', function() {
    const noteTextArea = document.getElementById('noteTextArea');
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const linkButton = document.getElementById('linkButton');
    const logoutButton = document.getElementById('logoutButton');
    const downloadButton = document.getElementById('downloadButton');
    let recognition;

    let isRecognizing = false;

    function startSpeechRecognition() {
        if (!isRecognizing) {
            isRecognizing = true;
            try {
                recognition = new webkitSpeechRecognition();
                recognition.continuous = true;
                recognition.interimResults = true;
                recognition.maxAlternatives = 3;
                recognition.lang = 'en-US';
                recognition.onstart = function() {
                    console.log('Speech recognition started...');
                    startButton.style.display = 'none';
                    stopButton.style.display = 'inline-block';
                    linkButton.disabled = true;
                };

                recognition.onresult = function(event) {
                    let interimTranscript = '';
                    for (let i = event.resultIndex; i < event.results.length; i++) {
                        const transcript = event.results[i][0].transcript;
                        if (event.results[i].isFinal) {
                            noteTextArea.value += transcript;
                        } else {
                            interimTranscript += transcript;
                        }
                    }
                    if (interimTranscript!== '') {
                        console.log('Interim result:', interimTranscript);
                    }
                };

                recognition.onerror = function(event) {
                    console.error(`Speech recognition error detected: ${event.error}`);
                    isRecognizing = false;
                };

                recognition.onend = function() {
                    startButton.style.display = 'inline-block';
                    stopButton.style.display = 'none';
                    linkButton.disabled = false;
                    downloadButton.disabled = false;
                    isRecognizing = false;
                };

                recognition.start();
            } catch (error) {
                console.error('Error starting speech recognition:', error);
                isRecognizing = false;
            }
        }
    }

    function stopSpeechRecognition() {
        if (isRecognizing) {
            recognition.stop();
            isRecognizing = false;
        }
    }

    startButton.addEventListener('click', startSpeechRecognition);
    stopButton.addEventListener('click', stopSpeechRecognition);

    linkButton.addEventListener('click', function() {
        let link = prompt('Enter the link:');
        if (link) {
            let linkText = `<a href="${link}" target="_blank" class="note-link">${link}</a>`;
            noteTextArea.value += `\n\n${linkText}\n`;
        }
    });

    logoutButton.addEventListener('click', function() {
        noteTextArea.value = '';
        downloadButton.disabled = true;
    });

    downloadButton.addEventListener('click', function() {
        const doc = new Document();
        const textLines = noteTextArea.value.split('\n');
        const paragraphs = textLines.map(line => new Paragraph(line));
        doc.addSection({ children: paragraphs });
        Packer.toBlob(doc).then(blob => {
            saveAs(blob, "notes.docx");
        }).catch(err => console.error('Error creating Word document:', err));
    });
}); 